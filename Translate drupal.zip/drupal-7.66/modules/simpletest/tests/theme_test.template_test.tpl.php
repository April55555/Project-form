<!-- Output for Theme API test -->
Fail: Template not overridden.
